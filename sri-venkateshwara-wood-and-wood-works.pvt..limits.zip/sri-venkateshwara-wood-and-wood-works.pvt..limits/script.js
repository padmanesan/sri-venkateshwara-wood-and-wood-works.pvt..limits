// Get references to elements
const learnMoreBtn = document.getElementById("learn-more-btn");
const moreContent = document.getElementById("more-content");

learnMoreBtn.addEventListener("click", () => {
    // Toggle visibility of the hidden content
    if (moreContent.style.display === "block") {
        moreContent.style.display = "none";
        learnMoreBtn.textContent = "Learn More";
    } else {
        moreContent.style.display = "block";
        learnMoreBtn.textContent = "Show Less";
    }
});