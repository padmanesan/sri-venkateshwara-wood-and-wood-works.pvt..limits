const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());

// Handle Order Submission
app.post('/process_order', (req, res) => {
  const { product, quantity, name, email, address } = req.body;

  if (!product || !quantity || !name || !email || !address) {
    return res.status(400).send('All fields are required.');
  }

  // Simulate saving order to a database
  console.log('Order Received:', {
    product,
    quantity,
    name,
    email,
    address,
  });

  // Respond with success
  res.status(200).send('Order placed successfully!');
});

// Start Server
const PORT = 5000;
app.listen(PORT, () => {
  console.log(Server running on http://localhost:${PORT});
});